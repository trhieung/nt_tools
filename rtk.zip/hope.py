import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

class BuilderConfig:
    key = b"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\x00" # 32 bytes
    iv  = b"\x00" * 16                            # 16 bytes
    
    # Danh sách URL cần bảo mật
    urls = [
        "http://localhost:8888/apis/uploads/",
        "http://localhost:8888/apis/reset/",
        "http://localhost:8888/apis/update/",
        "http://localhost:8888/apis/infor/"
    ]

def build_and_patch():
    # 1. Tạo khối dữ liệu thô 512 bytes (4 URL * 128 bytes)
    raw_payload = bytearray()
    for url in BuilderConfig.urls:
        # Chuyển string sang bytes và ép độ dài đúng 128 bằng null bytes (\x00)
        url_bytes = url.encode('utf-8').ljust(128, b'\x00')
        raw_payload += url_bytes

    # 2. Mã hóa Batch bằng AES-256-CTR
    cipher = Cipher(algorithms.AES(BuilderConfig.key), modes.CTR(BuilderConfig.iv))
    encryptor = cipher.encryptor()
    encrypted_batch = encryptor.update(raw_payload) + encryptor.finalize()
    print(len(encrypted_batch))

    # 3. Đọc EXE và tìm vị trí Key
    exe_path = 'build/release/main.exe'
    with open(exe_path, 'rb') as f:
        dt = bytearray(f.read())

    idx = dt.find(BuilderConfig.key)
    if idx == -1:
        return print("[-] Lỗi: Không tìm thấy chuỗi mồi trong EXE!")

    # 4. Vá dữ liệu: Giữ nguyên Key(32) + IV(16), sau đó vá 512 bytes URL đã mã hóa
    patched_data = BuilderConfig.key + BuilderConfig.iv + encrypted_batch
    dt[idx:idx+512+48] = patched_data

    with open('check.exe', 'wb') as f:
        f.write(dt)
    
    print(f"[+] Đã tạo check.exe. Dữ liệu URL ({len(patched_data)} bytes) đã được mã hóa.")

build_and_patch()


