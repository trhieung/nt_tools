#include <iostream>
#include <cstring>
#include <vector>
#include <fstream>
#include <cstdint>
#include <openssl/evp.h>
#include <openssl/aes.h>

#pragma pack(push, 1) // Ép các thành phần nằm sát nhau 100%, không padding
struct Data1 {
    char key[32] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    char iv[16] = {0};
    char url_post[128]   = "http://localhost:8888/apis/uploads/";
    char url_reset[128]  = "http://localhost:8888/apis/reset/";
    char url_update[128] = "http://localhost:8888/apis/update/";
    char url_infor[128]  = "http://localhost:8888/apis/infor/";
};
#pragma pack(pop)

struct Data2 {
    std::vector<uint8_t> key;
    std::vector<uint8_t> iv;
    std::vector<uint8_t> url_post;
    std::vector<uint8_t> url_reset;
    std::vector<uint8_t> url_update;
    std::vector<uint8_t> url_infor;
};

static const Data1 globalData1;
class NTCrypto {
private:
    Data2 config;

protected:
    std::string bytes_to_string(const std::vector<uint8_t>& data) {
        // Khởi tạo string từ vector
        std::string s(data.begin(), data.end());
        // Tìm vị trí ký tự null đầu tiên để cắt bỏ phần thừa của mảng 128 bytes
        size_t null_pos = s.find('\0');
        if (null_pos != std::string::npos) {
            s.resize(null_pos);
        }
        return s;
    }

    std::vector<uint8_t> aes_ctr_transform(const std::vector<uint8_t>& data, const uint8_t* key, const uint8_t* iv) {
        EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
        std::vector<uint8_t> out_data(data.size());
        int out_len;

        // CTR mode không cần padding, 1 byte vào = 1 byte ra
        EVP_EncryptInit_ex(ctx, EVP_aes_256_ctr(), NULL, key, iv);
        EVP_EncryptUpdate(ctx, out_data.data(), &out_len, data.data(), data.size());
        
        EVP_CIPHER_CTX_free(ctx);
        return out_data;
    }

public:
    NTCrypto() {
        // Ép kiểu về uint8_t* để cộng offset theo từng BYTE
        const uint8_t* start_ptr = reinterpret_cast<const uint8_t*>(&globalData1);
        
        // Chỉ lấy phần URL (từ byte 48 đến hết byte 560)
        // Vì Python chỉ mã hóa phần URL (512 bytes)
        std::vector<uint8_t> cipher_urls(start_ptr + 48, start_ptr + sizeof(Data1));

        const uint8_t* key_ptr = reinterpret_cast<const uint8_t*>(globalData1.key);
        const uint8_t* iv_ptr  = reinterpret_cast<const uint8_t*>(globalData1.iv);

        // Giải mã khối 512 bytes
        std::vector<uint8_t> plaintext_urls = decrypt(cipher_urls, key_ptr, iv_ptr);

        if (plaintext_urls.size() == 512) {
            // Nạp lại Key/IV (lấy trực tiếp từ vùng không mã hóa)
            config.key.assign(key_ptr, key_ptr + 32);
            config.iv.assign(iv_ptr, iv_ptr + 16);

            // Cắt dữ liệu từ khối 512 bytes đã giải mã
            auto base = plaintext_urls.begin();
            config.url_post.assign(base,       base + 128);
            config.url_reset.assign(base + 128, base + 256);
            config.url_update.assign(base + 256, base + 384);
            config.url_infor.assign(base + 384, base + 512);
            
            std::cout << "[+] Config decrypted and loaded to RAM.\n";
        }
    }

    std::vector<uint8_t> decrypt(const std::vector<uint8_t>& cipher_text, const uint8_t* key, const uint8_t* iv) {
        // Với CTR mode, encrypt và decrypt dùng chung một hàm logic
        return aes_ctr_transform(cipher_text, key, iv);
    }

    std::vector<uint8_t> encrypt(const std::vector<uint8_t>& plain_text, const uint8_t* key, const uint8_t* iv) {
        return aes_ctr_transform(plain_text, key, iv);
    }

    void verify() {
        std::cout << "\n--- Verification ---" << std::endl;
        // std::cout << "key:   " << globalData1.key << std::endl;
        std::cout << "Key:   "      << bytes_to_string(config.key) << std::endl;
        std::cout << "URL Post:   " << bytes_to_string(config.url_post) << std::endl;
        std::cout << "URL Reset:  " << bytes_to_string(config.url_reset) << std::endl;
        std::cout << "URL Update: " << bytes_to_string(config.url_update) << std::endl;
        std::cout << "URL Infor:  " << bytes_to_string(config.url_infor) << std::endl;
        
        // In độ dài thực tế để kiểm tra offset có chuẩn không
        std::cout << "Key Size:   " << config.key.size() << " bytes" << std::endl;
        std::cout << "--------------------\n" << std::endl;
    }
};

int main() {
    NTCrypto crypto;
    crypto.verify();
    return 0;
}